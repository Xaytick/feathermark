FeatherMark v0.4.36 便携版 (Windows x86-64)
双击 feathermark.exe 运行，无需安装。
要求 Windows 10/11 64 位 + Edge WebView2。
默认中文，设置 → 编辑 → 界面语言 可切英文。
feathermark.exe.manifest 请与 exe 保持同目录。
