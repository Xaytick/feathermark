FeatherMark v0.4.37 便携版 (Windows x86-64)
双击 feathermark.exe 运行，无需安装。要求 Windows 10/11 64 位 + Edge WebView2。
默认中文，设置 → 编辑 → 界面语言 可切英文。
本版修复：排版整理把"补空格"误判为改字导致失败的问题。
